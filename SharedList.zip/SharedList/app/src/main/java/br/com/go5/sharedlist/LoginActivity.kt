package br.com.go5.sharedlist

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.TextInputEditText
import android.widget.Button

class LoginActivity : AppCompatActivity() {

    val btnLogin: Button? = null
    val editTextUsername: TextInputEditText? = null
    val editTextPassowrd: TextInputEditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnLogin?.setOnClickListener {
            signIn()
        }

    }


    private fun signIn() {

    }
}
